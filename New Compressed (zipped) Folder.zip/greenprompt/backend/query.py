import json
import os
import pandas as pd
import httpx
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings

# ==========================================
# PART 1: YOUR CARBON FOOTPRINT ENGINE (TASK 4)
# ==========================================

class CarbonFootprintEngine:
    def __init__(self):
        # 1. Load regional carbon data (Fallback values if regions.txt isn't parsed)
        # Values represent gCO2e per kWh
        self.regional_intensity = {
            "us-west": 250,   
            "eu-north": 40,   # Greenest region
            "asia-east": 450, 
            "default": 300
        }
        
        # 2. Hardware / Model power efficiency (kWh per 1000 tokens)
        self.model_power_factors = {
            "gpt-4": 0.005,
            "gpt-3.5": 0.001,
            "deepseek-v3": 0.004,
            "default": 0.003
        }

    def calculate_co2e(self, tokens, region, model):
        """Core carbon formula: Tokens * Power * Regional Intensity"""
        intensity = self.regional_intensity.get(region.lower(), self.regional_intensity["default"])
        power_factor = self.model_power_factors.get(model.lower(), self.model_power_factors["default"])
        
        emissions = (tokens / 1000) * power_factor * intensity
        return round(emissions, 4)

    def classify_severity(self, emissions):
        """Adds severity classification for the dashboard"""
        if emissions < 1.0: return "Low (Green)"
        elif emissions < 5.0: return "Medium (Yellow)"
        else: return "High (Red)"

    def generate_recommendation(self, region, severity):
        """Generates optimization recommendations based on severity"""
        if severity == "High (Red)" and region.lower() != "eu-north":
            return "Recommendation: Route traffic to eu-north for lower carbon intensity."
        elif severity == "Medium (Yellow)":
            return "Recommendation: Optimize prompt length to reduce token usage."
        return "Optimal efficiency."

    def process_production_logs(self, log_filepath, output_filepath):
        """Parses the log file, calculates carbon, and saves the results."""
        if not os.path.exists(log_filepath):
            print(f"⚠️ Warning: Log file not found at {log_filepath}")
            return
            
        print(f"\n🌱 Starting Carbon Engine: Processing logs from {log_filepath}...")
        
        # NOTE: Assuming the log file is a JSON array. 
        # If it's a CSV or text-based log, you can swap this to pd.read_csv()
        try:
            with open(log_filepath, 'r') as f:
                logs = json.load(f)
        except json.JSONDecodeError:
            print("⚠️ Error: Log file is not valid JSON. Please update the parser.")
            return

        processed_data = []
        for log in logs:
            emissions = self.calculate_co2e(log.get('tokens', 0), log.get('region', 'default'), log.get('model', 'default'))
            severity = self.classify_severity(emissions)
            recommendation = self.generate_recommendation(log.get('region', 'default'), severity)
            
            processed_data.append({
                "Team": log.get('team', 'Unknown'),
                "Model": log.get('model', 'Unknown'),
                "Region": log.get('region', 'Unknown'),
                "Tokens": log.get('tokens', 0),
                "Emissions_gCO2e": emissions,
                "Severity": severity,
                "Recommendation": recommendation
            })

        # Store carbon results for Teammate 4's Dashboard
        df = pd.DataFrame(processed_data)
        df.to_csv(output_filepath, index=False)
        print(f"✅ Carbon calculation complete! Results saved to {output_filepath}\n")


# ==========================================
# PART 2: EXISTING RAG & VECTOR DB SETUP
# ==========================================

def test_vector_db_retrieval():
    print("🔍 Testing Vector Database Retrieval...")
    client = httpx.Client(verify=False)

    embedding_model = OpenAIEmbeddings(
        base_url="https://genailab.tcs.in",
        model="azure/genailab-maas-text-embedding-3-large",
        api_key="YOUR_API_KEY_HERE", # Replaced plain-text key for safety
        http_client=client
    )

    # Fixed the path to match your folder structure (vector_db instead of vectordb)
    vectordb = Chroma(
        persist_directory="../vector_db/chroma_db",
        embedding_function=embedding_model
    )

    query = "What are carbon emissions?"
    results = vectordb.similarity_search_with_score(query, k=3)

    for doc, score in results:
        print("\nSOURCE:")
        print(doc.metadata)
        print("CONTENT:")
        print(doc.page_content[:500])


# ==========================================
# EXECUTION BLOCK
# ==========================================
if __name__ == "__main__":
    # 1. Run your Carbon Engine
    engine = CarbonFootprintEngine()
    
    # Using the exact file names from your screenshot
    log_file = "../data/llm_usage_log_001.txt"
    output_file = "../data/carbon_results.csv"
    
    # If the file doesn't exist yet, we create a dummy one just so the code doesn't crash during testing
    if not os.path.exists(log_file):
        dummy_logs = [
            {"team": "Engineering", "model": "deepseek-v3", "region": "us-west", "tokens": 12500},
            {"team": "Marketing", "model": "gpt-4", "region": "eu-north", "tokens": 4000}
        ]
        with open(log_file, "w") as f:
            json.dump(dummy_logs, f)
            
    engine.process_production_logs(log_file, output_file)
    
    # 2. Run the existing vector retrieval test
    try:
        test_vector_db_retrieval()
    except Exception as e:
        print(f"⚠️ Vector DB search failed (expected if DB isn't populated yet): {e}")