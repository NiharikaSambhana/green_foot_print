from pathlib import Path

from langchain_community.document_loaders import (
    TextLoader,
    CSVLoader
)

from langchain.text_splitters import RecursiveCharacterTextSplitter

from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
import httpx

client = httpx.Client(verify=False)


DATA_FOLDER = "../data"

PERSIST_DIRECTORY = "../vector_db/chroma_db"

# Load documents

def load_documents():

    docs = []

    data_path = Path(DATA_FOLDER)

    for file in data_path.iterdir():

        if file.suffix == ".txt":

            loader = TextLoader(str(file))
            docs.extend(loader.load())

        elif file.suffix == ".csv":

            loader = CSVLoader(str(file))
            docs.extend(loader.load())

    return docs

# Test loading

documents = load_documents()

print("Documents Loaded:", len(documents))

# chunking

splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)



# Add meta data for Traceability

for idx, doc in enumerate(documents):
    doc.metadata["doc_id"] = idx

chunks = splitter.split_documents(documents)

for idx, chunk in enumerate(chunks):
    chunk.metadata["chunk_id"] = idx
    chunk.metadata["document_name"] = chunk.metadata.get(
        "source",
        "unknown"
    )

# Check chunks

print("Documents Chunked:", len(chunks))

#Embedding

embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key="sk-k4NQXpytjb1jTyqHPnjcFQ",
    http_client=client
)

# Chroma_db

vectordb = Chroma.from_documents(
    documents=chunks,
    embedding_function=embedding_model,
    persist_directory=PERSIST_DIRECTORY
)

vectordb.persist()
