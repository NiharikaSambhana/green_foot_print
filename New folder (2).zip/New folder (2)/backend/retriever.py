from query import retrieve_chunks


def get_context(
    query,
    k=5
):

    results = retrieve_chunks(
        query=query,
        k=k
    )

    context = "\n\n".join(
        [
            item["content"]
            for item in results
        ]
    )

    return context