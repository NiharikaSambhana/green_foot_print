from chatbot import ask_question

question = """
What causes carbon emissions?
"""

answer = ask_question(
    question
)

print("\nAnswer:\n")

print(answer)