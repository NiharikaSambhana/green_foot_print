from retriever import retrieve_chunks
#  SSL
import requests
import urllib3
import os
import ssl
import httpx

os.environ["TIKTOKEN_CACHE_DIR"] = "./tiktoken_cache"

ssl._create_default_https_context=ssl._create_unverified_context

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_orig_get=requests.get
requests.get = lambda url, **kwargs: _orig_get(
    url, verify=False, **{k: v for k, v in kwargs.items()  if k!= "verify"}
 )

sync_client=httpx.Client(verify=False)
async_client=httpx.AsyncClient(verify=False)

client = httpx.Client(
    verify=False
)

question = "What is carbon emission?"

results = retrieve_chunks(
    question,
    k=3
)

print("\nSemantic Retrieval Results\n")

for idx, r in enumerate(results, start=1):

    print(f"\nResult {idx}")

    print(
        f"Score: {r['score']}"
    )

    print(
        f"Source: {r['source']}"
    )

    print(
        f"Chunk ID: {r['chunk_id']}"
    )

    print("\nContent:")

    print(
        r["content"][:500]
    )

    print("\n" + "-" * 60)