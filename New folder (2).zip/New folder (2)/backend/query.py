import httpx
import requests
import urllib3
import os
import ssl

from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

from config import (
    BASE_URL,
    EMBEDDING_MODEL,
    API_KEY,
    VECTOR_DB
)

# SSL SETTINGS
# --------------------------------------------------

os.environ["TIKTOKEN_CACHE_DIR"] = "./tiktoken_cache"

ssl._create_default_https_context = (
    ssl._create_unverified_context
)

urllib3.disable_warnings(
    urllib3.exceptions.InsecureRequestWarning
)

_orig_get = requests.get

requests.get = lambda url, **kwargs: _orig_get(
    url,
    verify=False,
    **{
        k: v
        for k, v in kwargs.items()
        if k != "verify"
    }
)

# --------------------------------------------------
# HTTP CLIENTS
# --------------------------------------------------

sync_client = httpx.Client(
    verify=False
)

async_client = httpx.AsyncClient(
    verify=False
)

# --------------------------------------------------
# EMBEDDING MODEL
# --------------------------------------------------

embedding_model = OpenAIEmbeddings(
    base_url=BASE_URL,
    model=EMBEDDING_MODEL,
    api_key=API_KEY,
    http_client=sync_client,
    http_async_client=async_client
)

# --------------------------------------------------
# LOAD CHROMA VECTOR DB
# --------------------------------------------------

vectordb = Chroma(
    persist_directory=VECTOR_DB,
    embedding_function=embedding_model
)

# --------------------------------------------------
# RETRIEVE CHUNKS
# --------------------------------------------------

def retrieve_chunks(
    query: str,
    k: int = 5
):

    results = (
        vectordb.similarity_search_with_score(
            query,
            k=k
        )
    )

    # Sort by score
    # Lower score = better match

    results = sorted(
        results,
        key=lambda x: x[1]
    )

    formatted_results = []

    for doc, score in results:

        score = round(score, 4)

        # Lower distance = better match
        confidence = round(
            max(0, (2 - score) / 2) * 100,
            2
        )

        # confidence = round(
        #     100 / (1 + score),
        #     2
        # )

        formatted_results.append(
            {
                "content":
                    doc.page_content,

                "score":
                    score,

                "confidence":
                    confidence,

                "source":
                    doc.metadata.get(
                        "source_file",
                        "unknown"
                    ),

                "chunk_id":
                    doc.metadata.get(
                        "chunk_id",
                        "N/A"
                    ),

                "document_type":
                    doc.metadata.get(
                        "document_type",
                        "unknown"
                    )
            }
        )   

    return formatted_results

# --------------------------------------------------
# TEST RETRIEVAL
# --------------------------------------------------

if __name__ == "__main__":

    query = "What are carbon emissions?"

    results = retrieve_chunks(
        query=query,
        k=3
    )

    print("\nSemantic Retrieval Results\n")

    for idx, item in enumerate(
        results,
        start=1
    ):

        print(
            f"\nResult {idx}"
        )

        print(
            f"Distance Score: "
            f"{item['score']}"
        )

        print(
            f"Confidence: "
            f"{item['confidence']}%"
        )

        print(
            f"Source File: "
            f"{item['source']}"
        )

        print(
            f"Document Type: "
            f"{item['document_type']}"
        )

        print(
            f"Chunk ID: "
            f"{item['chunk_id']}"
        )

        print("\nContent:")

        print(
            item["content"][:500]
        )

        print(
            "\n" + "-" * 60
        )