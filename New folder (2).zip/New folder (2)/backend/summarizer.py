def summarize_results(results):

    total_emission = results.get(
        "total_emission",
        0
    )

    highest_team = results.get(
        "highest_team",
        "Unknown"
    )

    high_severity = results.get(
        "high_severity_count",
        0
    )

    summary = f"""
SUSTAINABILITY SUMMARY

Total CO2e:
{total_emission}

Highest Emission Team:
{highest_team}

High Severity Cases:
{high_severity}

Recommendations:

• Reduce token usage

• Use smaller models

• Enable caching

• Use low-carbon regions

• Optimize prompts
"""

    return summary