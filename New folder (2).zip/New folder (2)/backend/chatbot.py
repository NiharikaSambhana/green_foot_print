from langchain_openai import ChatOpenAI

from rag import (
    SYSTEM_PROMPT,
    retrieve_context,
    is_allowed_query,
    rejection_message
)

from config import (
    BASE_URL,
    API_KEY
)

# ----------------------------------
# LLM
# ----------------------------------

llm = ChatOpenAI(

    base_url=BASE_URL,

    api_key=API_KEY,

    model="azure_ai/genailab-maas-DeepSeek-V3-0324",

    temperature=0
)

# ----------------------------------
# MAIN CHAT FUNCTION
# ----------------------------------

def ask_question(question):

    # Guardrail

    if not is_allowed_query(question):

        return rejection_message()

    # Retrieve Context

    context, sources = retrieve_context(
        question
    )

    # Prompt

    prompt = f"""
{SYSTEM_PROMPT}

Context:

{context}

Question:

{question}

Answer:
"""

    # LLM Response

    response = llm.invoke(prompt)

    return response.content