from pathlib import Path
import httpx
from langchain_community.document_loaders import TextLoader, CSVLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
import streamlit as st


from config import (
    BASE_URL,
    EMBEDDING_MODEL,
    API_KEY,
    DATA_FOLDER,
    VECTOR_DB,
    CHUNK_SIZE,
    CHUNK_OVERLAP
)

# HTTP CLIENT

client = httpx.Client(
    verify=False
)
#  SSL
import requests
import urllib3
import os
import ssl

os.environ["TIKTOKEN_CACHE_DIR"] = "./tiktoken_cache"

ssl._create_default_https_context=ssl._create_unverified_context

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_orig_get=requests.get
requests.get = lambda url, **kwargs: _orig_get(
    url, verify=False, **{k: v for k, v in kwargs.items()  if k!= "verify"}
 )

sync_client=httpx.Client(verify=False)
async_client=httpx.AsyncClient(verify=False)

# LOAD DOCUMENTS

def load_documents():

    documents = []

    data_path = Path(DATA_FOLDER)

    for file in data_path.iterdir():

        # TXT and LOG files

        if file.suffix.lower() in [".txt",".log"]:

            loader = TextLoader(
                str(file),
                encoding="utf-8"
            )

            documents.extend(
                loader.load()
            )
 
        # CSV files

        elif file.suffix.lower() == ".csv":

            loader = CSVLoader(
                str(file)
            )

            documents.extend(
                loader.load()
            )

    return documents


# BUILD VECTOR DATABASE

def build_vector_db():

    print(
        "\nLoading documents..."
    )

    documents = load_documents()

    print(
        f"Documents Loaded: {len(documents)}"
    )

    # Chunking

    splitter = (
        RecursiveCharacterTextSplitter(
            chunk_size=CHUNK_SIZE,
            chunk_overlap=CHUNK_OVERLAP
        )
    )

    chunks = (
        splitter.split_documents(
            documents
        )
    )

    print(
        f"Chunks Created: {len(chunks)}"
    )

    # Metadata

    for idx, chunk in enumerate(chunks):

        chunk.metadata["chunk_id"] = idx

        chunk.metadata["source_file"] = (
            chunk.metadata.get(
                "source",
                "unknown"
            )
        )

        chunk.metadata["document_type"] = (
            Path(
                chunk.metadata[
                    "source_file"
                ]
            ).suffix
        )

    # Embedding Model

    embedding_model = (
        OpenAIEmbeddings(
            base_url=BASE_URL,
            model=EMBEDDING_MODEL,
            api_key=API_KEY,
            http_client=sync_client,
            # http_async_client=async_client,
        )
    )

    # Create ChromaDB

    vectordb = (
        Chroma.from_documents(
            documents=chunks,
            embedding=embedding_model,
            persist_directory=VECTOR_DB
        )
    )

    vectordb.persist()

    print(
        "\nVector Database Created Successfully"
    )

    print(
        f"Stored in: {VECTOR_DB}"
    )

    return vectordb


# MAIN

if __name__ == "__main__":

    build_vector_db()