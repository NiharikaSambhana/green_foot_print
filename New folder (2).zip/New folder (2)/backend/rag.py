from retriever import retrieve_chunks

# ----------------------------------
# DOMAIN GUARDRAIL
# ----------------------------------

ALLOWED_TOPICS = [

    "carbon",
    "co2",
    "co2e",
    "sustainability",
    "green ai",
    "emission",
    "emissions",
    "energy",
    "llm",
    "token",
    "power consumption",
    "carbon footprint",
    "climate",
    "net zero"
]

# ----------------------------------
# QUERY VALIDATION
# ----------------------------------

def is_allowed_query(query):

    query = query.lower()

    for topic in ALLOWED_TOPICS:

        if topic in query:
            return True

    return False

# ----------------------------------
# REJECTION MESSAGE
# ----------------------------------

def rejection_message():

    return """
This chatbot only supports:

• Carbon Footprint Analysis
• Sustainability Analytics
• Green AI
• CO2e Emission Analysis
• Energy Consumption

Please ask sustainability-related questions.
"""

# ----------------------------------
# SYSTEM PROMPT
# ----------------------------------

SYSTEM_PROMPT = """
You are GreenPrompt AI.

You are an enterprise sustainability expert.

Rules:

1. Answer ONLY using provided context.

2. Never hallucinate.

3. If answer not available say:

Insufficient sustainability data available.

4. Be concise.

5. Provide optimization recommendations.
"""

# ----------------------------------
# RETRIEVE CONTEXT
# ----------------------------------

def retrieve_context(question):

    results = retrieve_chunks(
        question,
        k=4
    )

    context = "\n\n".join(

        [
            r["content"]
            for r in results
        ]

    )

    return context, results