from langchain_openai import ChatOpenAI

from config import (
    BASE_URL,
    API_KEY
)

judge = ChatOpenAI(

    base_url=BASE_URL,

    api_key=API_KEY,

    model="azure_ai/genailab-maas-DeepSeek-V3-0324",

    temperature=0
)

def evaluate_answer(question, answer):

    prompt = f"""
Evaluate answer quality.

Question:
{question}

Answer:
{answer}

Give:

Accuracy /10
Relevance /10
Groundedness /10

Overall Score:
"""

    result = judge.invoke(
        prompt
    )

    return result.content