from chatbot import ask_question

question = """
Who is Prime Minister of India?
"""

answer = ask_question(
    question
)

print(answer)